# Snail jumper
**Neuroevolution game assignment.**  
**Fall 2021 - Computer Intelligence.**  

This game has been developed as an assignment for students at Amirkabir University of Technology to apply neuroevolution using a simple game.  
![Snail Jumber](SnailJumper.png)
